//
//  BLEManager.swift
//  BreathingGuide
//
//  Created by Steven Bailey on 11/4/25.
//

import Foundation
import CoreBluetooth

class BLEManager: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {

   @Published var connectedBPDevice: CBPeripheral?
   @Published var systolic: Double?
   @Published var diastolic: Double?
   @Published var heartRate: Double?

   private var centralManager: CBCentralManager!
   private var bpPeripheral: CBPeripheral?

   private let bpServiceUUID = CBUUID(string: "1810") // Blood Pressure Service
   private let bpMeasurementUUID = CBUUID(string: "2A35")
   private let heartRateServiceUUID = CBUUID(string: "180D")
   private let heartRateMeasurementUUID = CBUUID(string: "2A37")

   override init() {
       super.init()
       centralManager = CBCentralManager(delegate: self, queue: nil)
   }

   // MARK: - Central Manager Delegate
   func centralManagerDidUpdateState(_ central: CBCentralManager) {
       if central.state == .poweredOn {
           centralManager.scanForPeripherals(withServices: [bpServiceUUID, heartRateServiceUUID],
                                             options: nil)
       }
   }

   func centralManager(_ central: CBCentralManager,
                       didDiscover peripheral: CBPeripheral,
                       advertisementData: [String: Any],
                       rssi RSSI: NSNumber) {
       bpPeripheral = peripheral
       connectedBPDevice = peripheral
       centralManager.stopScan()
       centralManager.connect(peripheral, options: nil)
   }

   func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
       peripheral.delegate = self
       peripheral.discoverServices([bpServiceUUID, heartRateServiceUUID])
   }

   // MARK: - Peripheral Delegate
   func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
       if let services = peripheral.services {
           for service in services {
               peripheral.discoverCharacteristics([bpMeasurementUUID, heartRateMeasurementUUID],
                                                  for: service)
           }
       }
   }

   func peripheral(_ peripheral: CBPeripheral,
                   didDiscoverCharacteristicsFor service: CBService,
                   error: Error?) {
       if let characteristics = service.characteristics {
           for characteristic in characteristics {
               peripheral.setNotifyValue(true, for: characteristic)
           }
       }
   }

   func peripheral(_ peripheral: CBPeripheral,
                   didUpdateValueFor characteristic: CBCharacteristic,
                   error: Error?) {
       guard let data = characteristic.value else { return }

       if characteristic.uuid == bpMeasurementUUID {
           parseBPData(data)
       } else if characteristic.uuid == heartRateMeasurementUUID {
           parseHRData(data)
       }
   }

   private func parseBPData(_ data: Data) {
       guard data.count >= 4 else { return }
       let systolicRaw = UInt16(data[1]) << 8 | UInt16(data[0])
       let diastolicRaw = UInt16(data[3]) << 8 | UInt16(data[2])
       DispatchQueue.main.async {
           self.systolic = Double(systolicRaw)
           self.diastolic = Double(diastolicRaw)
       }
   }

   private func parseHRData(_ data: Data) {
       guard let bpm = data.first else { return }
       DispatchQueue.main.async { self.heartRate = Double(bpm) }
   }
}
