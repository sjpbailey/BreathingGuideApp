//
//  HealthKitManager.swift
//  BreathingGuide
//
//  Created by Steven Bailey on 11/4/25.
//

import Foundation
import HealthKit

class HealthKitManager: ObservableObject {

   let healthStore = HKHealthStore()

   // MARK: - Published Vitals
   @Published var systolic: Double?
   @Published var diastolic: Double?
   @Published var heartRate: Double?

   init() {
       requestAuthorization()
       fetchLatestVitals()
   }

   // MARK: - HealthKit Authorization
   func requestAuthorization() {
       guard HKHealthStore.isHealthDataAvailable() else { return }

       let types: Set = [
           HKObjectType.quantityType(forIdentifier: .bloodPressureSystolic)!,
           HKObjectType.quantityType(forIdentifier: .bloodPressureDiastolic)!,
           HKObjectType.quantityType(forIdentifier: .heartRate)!
       ]

       healthStore.requestAuthorization(toShare: types, read: types) { success, error in
           if let error = error {
               print("HealthKit authorization error: \(error.localizedDescription)")
           } else {
               print("HealthKit authorized successfully.")
           }
       }
   }

   // MARK: - Fetch Latest Vitals
   func fetchLatestVitals(completion: @escaping () -> Void = {}) {
       fetchLatestBloodPressure {
           self.fetchLatestHeartRate {
               completion()
           }
       }
   }

   private func fetchLatestBloodPressure(completion: @escaping () -> Void = {}) {
       let systolicType = HKQuantityType.quantityType(forIdentifier: .bloodPressureSystolic)!
       let diastolicType = HKQuantityType.quantityType(forIdentifier: .bloodPressureDiastolic)!
       let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)

       let systolicQuery = HKSampleQuery(sampleType: systolicType,
                                         predicate: nil,
                                         limit: 1,
                                         sortDescriptors: [sort]) { _, results, _ in
           if let sample = results?.first as? HKQuantitySample {
               DispatchQueue.main.async {
                   self.systolic = sample.quantity.doubleValue(for: .millimeterOfMercury())
               }
           }
           completion()
       }

       healthStore.execute(systolicQuery)

       let diastolicQuery = HKSampleQuery(sampleType: diastolicType,
                                          predicate: nil,
                                          limit: 1,
                                          sortDescriptors: [sort]) { _, results, _ in
           if let sample = results?.first as? HKQuantitySample {
               DispatchQueue.main.async {
                   self.diastolic = sample.quantity.doubleValue(for: .millimeterOfMercury())
               }
           }
           completion()
       }

       healthStore.execute(diastolicQuery)
   }

   private func fetchLatestHeartRate(completion: @escaping () -> Void = {}) {
       let heartRateType = HKQuantityType.quantityType(forIdentifier: .heartRate)!
       let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)

       let query = HKSampleQuery(sampleType: heartRateType,
                                 predicate: nil,
                                 limit: 1,
                                 sortDescriptors: [sort]) { _, results, _ in
           if let sample = results?.first as? HKQuantitySample {
               DispatchQueue.main.async {
                   self.heartRate = sample.quantity.doubleValue(for: HKUnit(from: "count/min"))
               }
           }
           completion()
       }

       healthStore.execute(query)
   }

   // MARK: - Save Vitals to HealthKit
   func saveSessionResults(systolic: Double, diastolic: Double, heartRate: Double) {
       guard HKHealthStore.isHealthDataAvailable() else { return }

       let now = Date()
       let systolicType = HKQuantityType.quantityType(forIdentifier: .bloodPressureSystolic)!
       let diastolicType = HKQuantityType.quantityType(forIdentifier: .bloodPressureDiastolic)!
       let heartRateType = HKQuantityType.quantityType(forIdentifier: .heartRate)!

       let systolicSample = HKQuantitySample(type: systolicType,
                                             quantity: HKQuantity(unit: .millimeterOfMercury(), doubleValue: systolic),
                                             start: now, end: now)

       let diastolicSample = HKQuantitySample(type: diastolicType,
                                              quantity: HKQuantity(unit: .millimeterOfMercury(), doubleValue: diastolic),
                                              start: now, end: now)

       let heartSample = HKQuantitySample(type: heartRateType,
                                          quantity: HKQuantity(unit: HKUnit(from: "count/min"), doubleValue: heartRate),
                                          start: now, end: now)

       healthStore.save([systolicSample, diastolicSample, heartSample]) { success, error in
           DispatchQueue.main.async {
               if success {
                   print("✅ Session results saved to HealthKit.")
               } else if let error = error {
                   print("❌ Error saving to HealthKit: \(error.localizedDescription)")
               }
           }
       }
   }
}
