//
//  SessionSummaryView.swift
//  BreathingGuide
//
//  Created by Steven Bailey on 11/4/25.
//

import SwiftUI

struct SessionSummaryReview: View {
   @ObservedObject var healthKitManager: HealthKitManager

   let beforeSystolic: Double
   let beforeDiastolic: Double
   let beforeHeartRate: Double

   var body: some View {
       VStack(spacing: 30) {
           Text("Session Summary")
               .font(.largeTitle)

           VStack(spacing: 10) {
               Group {
                   HStack {
                       Text("BP Before:")
                       Spacer()
                       Text("\(Int(beforeSystolic))/\(Int(beforeDiastolic)) mmHg")
                   }

                   HStack {
                       Text("HR Before:")
                       Spacer()
                       Text("\(Int(beforeHeartRate)) bpm")
                   }

                   HStack {
                       Text("BP After:")
                       Spacer()
                       Text(healthKitManager.systolic != nil && healthKitManager.diastolic != nil ?
                            "\(Int(healthKitManager.systolic!))/\(Int(healthKitManager.diastolic!)) mmHg" :
                            "--/--")
                   }

                   HStack {
                       Text("HR After:")
                       Spacer()
                       Text(healthKitManager.heartRate != nil ?
                            "\(Int(healthKitManager.heartRate!)) bpm" :
                            "--")
                   }
               }
               .font(.title2)
           }

           Spacer()

           Button("Recheck Vitals") {
               // Fetch fresh vitals after user takes new measurement
               healthKitManager.refresh()
           }
           .padding()
           .background(Color.blue.opacity(0.7))
           .foregroundColor(.white)
           .cornerRadius(10)

       }
       .padding()
       .onAppear {
           // Optional: refresh automatically when view appears
           healthKitManager.refresh()
       }
   }
}

struct SessionSummaryReview_Previews: PreviewProvider {
   static var previews: some View {
       SessionSummaryReview(
           healthKitManager: HealthKitManager(),
           beforeSystolic: 120,
           beforeDiastolic: 80,
           beforeHeartRate: 70
       )
   }
}
