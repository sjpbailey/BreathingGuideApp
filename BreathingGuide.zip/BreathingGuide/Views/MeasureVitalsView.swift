//
//  MeasureVitalsView.swift
//  BreathingGuide
//
//  Created by Steven Bailey on 11/5/25.
//

import SwiftUI

struct MeasureVitalsView: View {
   @StateObject private var healthKitManager = HealthKitManager()

   @State private var sessionTime: Int = 300 // default 5 minutes

   var body: some View {
       VStack(spacing: 30) {
           Text("Breathing Guide")
               .font(.largeTitle)

           VStack(spacing: 10) {
               HStack {
                   Text("Systolic:")
                   Spacer()
                   Text(healthKitManager.systolic != nil ? "\(Int(healthKitManager.systolic!)) mmHg" : "--")
               }

               HStack {
                   Text("Diastolic:")
                   Spacer()
                   Text(healthKitManager.diastolic != nil ? "\(Int(healthKitManager.diastolic!)) mmHg" : "--")
               }

               HStack {
                   Text("Heart Rate:")
                   Spacer()
                   Text(healthKitManager.heartRate != nil ? "\(Int(healthKitManager.heartRate!)) bpm" : "--")
               }
           }
           .font(.title2)

           // Slider for breathing session duration
           VStack {
               Text("Session Duration: \(sessionTime) seconds")
               Slider(value: Binding(
                   get: { Double(sessionTime) },
                   set: { sessionTime = Int($0) }
               ), in: 60...600, step: 10)
           }
           .padding(.horizontal)

           Button("Refresh Vitals") {
               healthKitManager.refresh()
           }
           .padding()
           .background(Color.blue.opacity(0.7))
           .foregroundColor(.white)
           .cornerRadius(10)

           Spacer()

           Button("Start Breathing Exercise") {
               // Call your breathing session here, pass sessionTime
           }
           .padding()
           .background(Color.green.opacity(0.7))
           .foregroundColor(.white)
           .cornerRadius(10)
       }
       .padding()
       .onAppear {
           healthKitManager.refresh()
       }
   }
}

struct MeasureVitalsView_Previews: PreviewProvider {
   static var previews: some View {
       MeasureVitalsView()
   }
}
