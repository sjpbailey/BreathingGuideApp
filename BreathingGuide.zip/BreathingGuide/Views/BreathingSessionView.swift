//
//  BreathingSessionView.swift
//  BreathingGuide
//
//  Created by Steven Bailey on 11/4/25.
//

import SwiftUI

struct BreathingSessionView: View {
   @EnvironmentObject var healthKitManager: HealthKitManager
   @EnvironmentObject var bleManager: BLEManager
   @Environment(\.scenePhase) private var scenePhase

   // MARK: - Session settings
   @State private var sessionTime: Int = 300 // default 5 minutes
   @State private var secondsElapsed = 0
   @State private var timer: Timer?

   @State private var inhaleDuration: Double = 4
   @State private var pauseDuration: Double = 0
   @State private var exhaleDuration: Double = 8

   @State private var isInhale = true
   @State private var isPausedPhase = false
   @State private var isExhale = false
   @State private var isSessionRunning = false
   @State private var isManuallyPaused = false

   // MARK: - BP/HR readings
   @State private var bpBefore: (Double?, Double?) = (nil, nil)
   @State private var hrBefore: Double? = nil
   @State private var bpAfter: (Double?, Double?) = (nil, nil)
   @State private var hrAfter: Double? = nil

   // MARK: - UI
   @State private var scale: CGFloat = 1.0
   @State private var showSummary = false

   var body: some View {
       VStack(spacing: 30) {
           // Current BP/HR before session
           VStack(spacing: 5) {
               Text("BP Before: \(bpBefore.0 ?? 0, specifier: "%.0f") / \(bpBefore.1 ?? 0, specifier: "%.0f") mmHg")
               Text("HR Before: \(hrBefore ?? 0, specifier: "%.0f") bpm")
           }

           Spacer()

           // Breathing circle
           ZStack {
               Circle()
                   .fill(
                       LinearGradient(
                           gradient: Gradient(colors: phaseColors()),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing
                       )
                   )
                   .frame(width: 200, height: 200)
                   .scaleEffect(scale)
                   .shadow(color: (phaseColors().last ?? .blue).opacity(0.5), radius: 20)
                   .animation(.easeInOut(duration: currentPhaseDuration()), value: scale)

               Text(currentPhaseLabel())
                   .font(.title)
                   .fontWeight(.bold)
                   .foregroundColor(.white)
           }

           // Progress bar
           ProgressView(value: Double(secondsElapsed), total: Double(sessionTime))
               .tint(.cyan)
               .scaleEffect(x: 1, y: 4, anchor: .center)
               .padding(.horizontal)

           // Session duration slider
           VStack(spacing: 12) {
               HStack {
                   Text("Session Duration: \(sessionTime / 60)m")
                   Slider(value: Binding(
                       get: { Double(sessionTime) / 60 },
                       set: { sessionTime = Int($0 * 60) }
                   ), in: 1...10, step: 1)
               }
           }
           .padding()

           // Controls
           HStack {
               Button(isManuallyPaused ? "Resume" : "Pause") {
                   togglePause()
               }
               .buttonStyle(.borderedProminent)
               .tint(.orange)

               Button("End Session") {
                   endSession()
               }
               .buttonStyle(.bordered)
               .tint(.red)
           }

           Text("Time Remaining: \((sessionTime - secondsElapsed) / 60)m \((sessionTime - secondsElapsed) % 60)s")
               .font(.headline)

           Spacer()
       }
       .padding()
       .onAppear {
           fetchInitialVitals()
           startSession()
           startBreathingCycle()
       }
       .onDisappear { timer?.invalidate() }
       .onChange(of: scenePhase) { _, newPhase in
           if newPhase == .background { endSession() }
       }
       .fullScreenCover(isPresented: $showSummary) {
           SessionSummaryView(
               bpBefore: bpBefore,
               hrBefore: hrBefore,
               bpAfter: bpAfter,
               hrAfter: hrAfter,
               healthKitManager: healthKitManager
           )
       }
   }

   // MARK: - HealthKit Fetch
   private func fetchInitialVitals() {
       bpBefore = (bleManager.systolic ?? healthKitManager.latestSystolic,
                   bleManager.diastolic ?? healthKitManager.latestDiastolic)
       hrBefore = bleManager.heartRate ?? healthKitManager.latestHeartRate
   }

   // MARK: - Breathing logic
   private func startSession() {
       isSessionRunning = true
       secondsElapsed = 0
       timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
           guard isSessionRunning, !isManuallyPaused else { return }
           secondsElapsed += 1
           if secondsElapsed >= sessionTime { endSession() }
       }
   }

   private func startBreathingCycle() {
       guard isSessionRunning else { return }
       performInhale()
   }

   private func performInhale() {
       guard isSessionRunning, !isManuallyPaused else { return }
       isInhale = true; isExhale = false; isPausedPhase = false
       withAnimation(.easeInOut(duration: inhaleDuration)) { scale = 1.5 }
       DispatchQueue.main.asyncAfter(deadline: .now() + inhaleDuration) {
           if self.pauseDuration > 0 { self.performPause() }
           else { self.performExhale() }
       }
   }

   private func performPause() {
       guard isSessionRunning, !isManuallyPaused else { return }
       isPausedPhase = true; isInhale = false; isExhale = false
       withAnimation(.easeInOut(duration: pauseDuration)) { scale = 1.4 }
       DispatchQueue.main.asyncAfter(deadline: .now() + pauseDuration) { self.performExhale() }
   }

   private func performExhale() {
       guard isSessionRunning, !isManuallyPaused else { return }
       isExhale = true; isInhale = false; isPausedPhase = false
       withAnimation(.easeInOut(duration: exhaleDuration)) { scale = 1.0 }
       DispatchQueue.main.asyncAfter(deadline: .now() + exhaleDuration) {
           if self.isSessionRunning && !self.isManuallyPaused { self.performInhale() }
       }
   }

   private func togglePause() {
       isManuallyPaused.toggle()
       if !isManuallyPaused {
           if isInhale { performInhale() }
           else if isPausedPhase { performPause() }
           else if isExhale { performExhale() }
       }
   }

   private func endSession() {
       isSessionRunning = false
       timer?.invalidate()

       // fetch new vitals for summary
       bpAfter = (bleManager.systolic ?? healthKitManager.latestSystolic,
                  bleManager.diastolic ?? healthKitManager.latestDiastolic)
       hrAfter = bleManager.heartRate ?? healthKitManager.latestHeartRate

       showSummary = true
   }

   // MARK: - Helpers
   private func phaseColors() -> [Color] {
       if isPausedPhase { return [.gray, .blue.opacity(0.3)] }
       else if isInhale { return [.cyan, .blue] }
       else { return [.pink, .purple] }
   }

   private func currentPhaseLabel() -> String {
       if isPausedPhase { return "Hold" }
       else if isInhale { return "Inhale" }
       else { return "Exhale" }
   }

   private func currentPhaseDuration() -> Double {
       if isPausedPhase { return pauseDuration }
       else if isInhale { return inhaleDuration }
       else { return exhaleDuration }
   }
}
