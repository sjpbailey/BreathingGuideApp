//
//  ContentView.swift
//  BreathingGuide
//
//  Created by Steven Bailey on 11/4/25.
//

import SwiftUI

struct ContentView: View {
   @EnvironmentObject var healthKitManager: HealthKitManager
   @EnvironmentObject var bleManager: BLEManager

   @State private var startSession = false

   var body: some View {
       NavigationStack {
           VStack(spacing: 30) {
               Text("BreathingGuide")
                   .font(.largeTitle)
                   .fontWeight(.bold)

               VStack {
                   Text("BP: \(bleManager.systolic ?? healthKitManager.systolic ?? 0, specifier: "%.0f") / \(bleManager.diastolic ?? healthKitManager.diastolic ?? 0, specifier: "%.0f") mmHg")
                   Text("HR: \(bleManager.heartRate ?? healthKitManager.heartRate ?? 0, specifier: "%.0f") bpm")
               }

               Button("Start Session") {
                   healthKitManager.readLatestVitals {
                       startSession = true
                   }
               }
               .font(.title2)
               .padding()
               .background(Color.blue.opacity(0.8))
               .foregroundColor(.white)
               .cornerRadius(15)

               // Modern navigation destination
               .navigationDestination(isPresented: $startSession) {
                   MeasureVitalsView()
               }
           }
           .padding()
       }
   }
}
